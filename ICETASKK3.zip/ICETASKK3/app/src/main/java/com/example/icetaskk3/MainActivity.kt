package com.example.icetaskk3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Button
import android.widget.Toast
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var etGuess: EditText
    private lateinit var tvDisplay: TextView
    private lateinit var btnGuess: Button
    private var intRandom: Int = 0
    private var numGuesses: Int = 0
    private val maxGuesses = 5

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etGuess = findViewById(R.id.etGuess)
        tvDisplay = findViewById(R.id.tvDisplay)
        btnGuess = findViewById(R.id.btnGuess)

        btnGuess.setOnClickListener {
            guessedNumber()
        }

        startGame()
    }

    private fun startGame() {
        etGuess.text.clear()
        tvDisplay.text = ""
        intRandom = Random.nextInt(1, 101)
        numGuesses = 0
        showToast(R.string.message_new_game)
        enableGuessButton()
    }

    private fun guessedNumber() {
        numGuesses++
        val guessText = etGuess.text.toString()

        if (guessText.isBlank()) {
            showToast(R.string.message_invalid_input)
            return
        }

        val intGuessNumber = guessText.toIntOrNull()

        if (intGuessNumber == null) {
            showToast(R.string.message_invalid_input)
            return
        }

        when {
            intGuessNumber == intRandom -> {
                tvDisplay.text = getString(R.string.message_correct_guess)
                showToast(R.string.message_win)
                disableGuessButton()
            }
            intGuessNumber > intRandom -> {
                tvDisplay.text = getString(R.string.message_high_guess)
            }
            else -> {
                tvDisplay.text = getString(R.string.message_low_guess)
            }
        }

        if (numGuesses == maxGuesses) {
            tvDisplay.text = getString(R.string.message_game_over, intRandom)
            showToast(R.string.message_game_over, intRandom)
            disableGuessButton()
        }

        etGuess.text.clear()
    }

    private fun showToast(messageResId: Int, vararg formatArgs: Any) {
        val message = if (formatArgs.isEmpty()) {
            getString(messageResId)
        } else {
            getString(messageResId, *formatArgs)
        }
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun enableGuessButton() {
        btnGuess.isEnabled = true
    }

    private fun disableGuessButton() {
        btnGuess.isEnabled=false}

}